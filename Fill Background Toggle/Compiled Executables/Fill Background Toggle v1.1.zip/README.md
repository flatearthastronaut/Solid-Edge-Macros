# Fill Background Toggle v1.1

Select one or more annotations in Solid Edge, then run `Compiled Executables/Fill Background Toggle v1.1.exe`. Each selected item switches its own background fill on or off. Run again to reverse it. Update your Solid Edge macro button to point to the v1.1 executable.

## New in v1.1

Text boxes are now supported through their own `Fill` property. The macro preserves the existing text-box fill color, text, and border settings. When enabled, the box uses the fill color configured in Solid Edge; it does not automatically replace that color with the drawing background color.

Dimensions, callouts/balloons, feature control frames, datum frames, and surface-finish symbols continue to use their existing annotation style override. The selected icon is retained. Other objects are skipped. Successful runs are silent; partial failures report selection indexes. The macro does not save the document.

## Build and test

Run `Build.cmd` on Windows to rebuild the x64 .NET Framework executable with the included icon. No Solid Edge interop DLLs need to accompany the executable.

Run `Test.ps1` for managed regression checks. `Test.ps1 -Live` requires Solid Edge and creates a temporary draft, checks annotations and text boxes, then closes it without saving and restores the original document. Run the live test only when ready to allow that temporary draft.

API references:
- https://support.industrysoftware.automation.siemens.com/trainings/se/106/api/SolidEdgeFrameworkSupport~TextBox~Fill.html
- https://support.industrysoftware.automation.siemens.com/trainings/se/107/api/SolidEdgeFramework~ObjectType.html

Validation: v1.0 was confirmed working by the user. v1.1 live Solid Edge verification must be performed on Windows.

2026-11-09 build validation: compiled successfully with Mono C# compiler for .NET Framework; all 11 managed regression checks passed. Verified x64 Windows GUI executable, version 1.1.0.0, and all seven embedded icon frames. Live Solid Edge testing is pending.
